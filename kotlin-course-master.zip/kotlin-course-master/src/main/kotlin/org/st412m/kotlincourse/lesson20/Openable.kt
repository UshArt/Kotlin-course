package org.st412m.kotlincourse.lesson20

interface Openable {
    fun open()

    fun closed()
}