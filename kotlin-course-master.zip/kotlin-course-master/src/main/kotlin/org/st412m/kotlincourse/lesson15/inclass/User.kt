package org.st412m.kotlincourse.lesson15.inclass

data class User(val id: Int, val name: String)  // используются для хранения, методы здесь делать нельзя
