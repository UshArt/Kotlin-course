package org.st412m.kotlincourse.lesson30

interface hasValue {
    val value: String
}