package org.st412m.kotlincourse.lesson20.homework

abstract class MechanicalWatch : Timable, Mechanical {
    override fun setTimer(time: Int) {
        TODO("Not yet implemented")
    }

    override fun performMechanicalAction() {
        TODO("Not yet implemented")
    }
}