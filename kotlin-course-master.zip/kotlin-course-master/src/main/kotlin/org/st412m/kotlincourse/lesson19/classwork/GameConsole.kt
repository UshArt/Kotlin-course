package org.st412m.kotlincourse.lesson19.classwork

class GameConsole {
    fun startGame(nameGame: String) {
        initHardware()
        loadGame(nameGame)
    }

    private fun initHardware(){}

    private fun loadGame(nameGame: String){}
}