package org.st412m.kotlincourse.lesson16

data class Item(
    val name: String,
    val type: String,
    val weight: Int
)
