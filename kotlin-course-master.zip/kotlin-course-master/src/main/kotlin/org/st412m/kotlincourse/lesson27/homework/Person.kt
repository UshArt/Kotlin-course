package org.st412m.kotlincourse.lesson27.homework

class Person (val name: String, val age: Int) {
    var email: String = ""
}
