package org.st412m.kotlincourse.lesson22.extensions

fun <T> Set<T>.funF(arg1: T): List<T>{
    return listOf()
}