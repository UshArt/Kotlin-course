package org.st412m.kotlincourse.lesson27.homework

class Employee(val name: String, val age: Int, val position: String) {
    var email: String = ""
    var department: String = "General"
}
