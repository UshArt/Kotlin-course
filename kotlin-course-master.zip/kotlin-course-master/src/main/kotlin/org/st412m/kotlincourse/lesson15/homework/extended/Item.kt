package org.st412m.kotlincourse.lesson15.homework.extended

data class Item(val name: String = "", val size: Int = name.length)
