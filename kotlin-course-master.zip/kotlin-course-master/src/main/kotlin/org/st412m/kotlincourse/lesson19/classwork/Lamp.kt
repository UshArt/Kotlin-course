package org.st412m.kotlincourse.lesson19.classwork

class Lamp {
    private var isOn = false

    fun turnOn() {
        isOn = true
    }

    fun turnOff() {
        isOn = false
    }

}