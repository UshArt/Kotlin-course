package org.st412m.kotlincourse.lesson32
/*
приходит телкфонный номер в таком формате +7 (XXX) XXX-XX-XX и преобразуется в такой 8952321 6548
если цифр меньше, то выкидываем исклоючение
 */

fun textToPhone(phoneNum: String): String {
    return phoneNum
}