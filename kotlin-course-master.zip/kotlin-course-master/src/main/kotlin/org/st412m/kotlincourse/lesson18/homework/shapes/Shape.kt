package org.st412m.kotlincourse.lesson18.homework.shapes

abstract class Shape {
    open fun figureArea(): Double {
        return 0.0
    }
}