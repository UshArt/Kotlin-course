package org.st412m.kotlincourse.lesson22.extensions

fun <K, V> Map<K, V>.funC(arg1: K, arg2: V): Boolean{
    return true
}