package org.st412m.kotlincourse.lesson19.classwork

fun main() {
    val account = Account(0.0)

    val student = Student("Ivan", 19, 3434)
    student.showAge()
}