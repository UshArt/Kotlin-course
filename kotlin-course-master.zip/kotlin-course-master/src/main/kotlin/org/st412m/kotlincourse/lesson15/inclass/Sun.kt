package org.st412m.kotlincourse.lesson15.inclass

object Sun {
    val mass: Int = 100000
}