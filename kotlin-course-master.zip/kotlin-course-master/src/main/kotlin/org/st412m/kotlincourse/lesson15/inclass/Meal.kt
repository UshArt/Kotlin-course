package org.st412m.kotlincourse.lesson15.inclass

data class Meal(val name: String = "Рыба", val ingredients: List<String>, val cost: Double)
