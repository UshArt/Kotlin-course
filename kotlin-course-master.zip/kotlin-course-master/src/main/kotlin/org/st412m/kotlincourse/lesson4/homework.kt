package org.st412m.kotlincourse.lesson4

//42
val answerUltimateQuestion: Int = 42

//98765432123456789L
val longNumFirst: Long = 98765432123456789L

//23.45f
val floatNumFirst: Float = 23.45f

//0.123456789
val doubleNumFirst: Double = 0.123456789

//"Kotlin & Java"
val stringFirst: String = "Kotlin & Java"

//false
val booleanFirst: Boolean = false

//'c'
val charFirst: Char = 'c'

//500
val intNumFirst: Int = 500

//4294967296L
val longNumSecond: Long = 4294967296L

//18.0f
val floatNumSecond: Float = 18.0f

//-0.001
val doubleNumSecond: Double = -0.001

//"OpenAI"
val stringSecond: String = "OpenAI"

//“true” - в задании кривые кавычки. Какой хитрец.
val stringThird: String = "true"
val booleanPossible: Boolean = true

//'9'
val charSecond: Char = '9'

//2048
val intNumSecond: Int = 2048

//10000000000L
val longNumThird: Long = 10000000000L

//5.75f
val floatNumThird: Float = 5.75f

//1.414
val doubleNumThird: Double = 1.414

//"Artificial Intelligence"
val stringFourth: String = "Artificial Intelligence"

//false
val booleanSecond: Boolean = false

//'@'
val charThird: Char = '@'

//1024
val intNumFourth: Int = 1024

//1234567890123L
val longNumFourth: Long = 1234567890123L

//10.01f
val floatNumFourth: Float = 10.01f

//-273.15
val doubleNumFourth: Double = -273.15

//"SpaceX"
val stringFifth: String = "SpaceX"

//true
val booleanThird: Boolean = true

//“🤯” - опять кривые кавычки
val stringSixth: String = "🤯"

//‘65535’ - неправильные кавычки
val stringSeventh: String = "65535"
val intPossible: Int = 65535

//72057594037927935L
val longNumFifth: Long = 72057594037927935L

//2.71828f
val floatNumFifth: Float = 2.71828f

//101.0101
val doubleNumFifth: Double = 101.0101

//"Quantum Computing"
val stringEighth: String = "Quantum Computing"

//false
val booleanFourth: Boolean = false

//'x'
val charFourth: Char = 'x'

//314 - short по приколу, чтобы было
val intNumShort: Short = 314

//123456789123456789L
val longNumSixth: Long = 123456789123456789L

//6.626f
val floatNumEighth: Float = 6.626f

//0.007
val doubleNumSixth: Double = 0.007

//"Android Studio"
val stringNinth: String = "Android Studio"
