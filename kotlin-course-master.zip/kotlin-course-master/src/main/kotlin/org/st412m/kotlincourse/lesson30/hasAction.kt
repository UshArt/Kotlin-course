package org.st412m.kotlincourse.lesson30

interface hasAction {
    fun action()
}