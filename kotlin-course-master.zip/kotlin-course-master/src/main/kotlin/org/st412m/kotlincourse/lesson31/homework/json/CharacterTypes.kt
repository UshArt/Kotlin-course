package org.st412m.kotlincourse.lesson31.homework.json

enum class CharacterTypes {
    CTO,
    UX_UI,
    TEAM_LEAD,
    BACKEND_DEV,
    QA,
}