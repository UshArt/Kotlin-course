package org.st412m.kotlincourse.lesson31.homework.unit

enum class Cereal(local: String) {
    BUCKWHEAT("Гречка"),
    RICE("Рис"),
    MILLET("Пшено"),
    PEAS("Горох"),
    BULGUR("Булгур")
}